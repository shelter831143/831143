set_perm_recursive $MODPATH 0 0 0755 0644

# 禁用HyperOS高级视效，更流畅
# resetprop --delete persist.sys.advanced_visual_release